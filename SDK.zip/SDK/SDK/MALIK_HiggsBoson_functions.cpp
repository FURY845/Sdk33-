// PUBG MOBILE (3.8.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Wed May  7 14:35:31 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function HiggsBoson.BaziState.OnControllerReconnected
// (Final, Native, Private)

void UBaziState::OnControllerReconnected()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.BaziState.OnControllerReconnected");

	UBaziState_OnControllerReconnected_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.BaziState.AddChori
// (Final, Native, Public, HasOutParms)
// Parameters:
// struct FChori                  Element                        (ConstParm, Parm, OutParm, ReferenceParm)

void UBaziState::AddChori(const struct FChori& Element)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.BaziState.AddChori");

	UBaziState_AddChori_Params params;
	params.Element = Element;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.BaziState.AddBazi
// (Final, Native, Public, HasOutParms)
// Parameters:
// struct FBazi                   Element                        (ConstParm, Parm, OutParm, ReferenceParm)

void UBaziState::AddBazi(const struct FBazi& Element)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.BaziState.AddBazi");

	UBaziState_AddBazi_Params params;
	params.Element = Element;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Vulou
// (Final, Native, Public, Const)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UClientGlueHiaSystem::Vulou()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Vulou");

	UClientGlueHiaSystem_Vulou_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc9
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// int                            Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::LuaFunc9(int Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.LuaFunc9");

	UClientGlueHiaSystem_LuaFunc9_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc8
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// int                            Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UClientGlueHiaSystem::LuaFunc8(int Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.LuaFunc8");

	UClientGlueHiaSystem_LuaFunc8_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc7
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// int                            Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UClientGlueHiaSystem::LuaFunc7(int Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.LuaFunc7");

	UClientGlueHiaSystem_LuaFunc7_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc6
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// int                            Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UClientGlueHiaSystem::LuaFunc6(int Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.LuaFunc6");

	UClientGlueHiaSystem_LuaFunc6_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc5
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// int                            Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UClientGlueHiaSystem::LuaFunc5(int Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.LuaFunc5");

	UClientGlueHiaSystem_LuaFunc5_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc4
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// int                            Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UClientGlueHiaSystem::LuaFunc4(int Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.LuaFunc4");

	UClientGlueHiaSystem_LuaFunc4_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc3
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// int                            Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::LuaFunc3(int Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.LuaFunc3");

	UClientGlueHiaSystem_LuaFunc3_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc2
// (Native, Event, Public, BlueprintEvent)

void UClientGlueHiaSystem::LuaFunc2()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.LuaFunc2");

	UClientGlueHiaSystem_LuaFunc2_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc1
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class AActor*                  PtrActor                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UClientGlueHiaSystem::LuaFunc1(class AActor* PtrActor)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.LuaFunc1");

	UClientGlueHiaSystem_LuaFunc1_Params params;
	params.PtrActor = PtrActor;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func9
// (Final, Native, Private)
// Parameters:
// class AActor*                  PtrWeapon                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::Func9(class AActor* PtrWeapon)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func9");

	UClientGlueHiaSystem_Func9_Params params;
	params.PtrWeapon = PtrWeapon;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func8
// (Final, Native, Private, HasOutParms)
// Parameters:
// class AActor*                  PtrWeapon                      (Parm, ZeroConstructor, IsPlainOldData)
// struct FBulletHitInfoUploadData UploadData                     (ConstParm, Parm, OutParm, ReferenceParm)
// struct FLocalShootHitData      LocalHitData                   (ConstParm, Parm, OutParm, ReferenceParm)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UClientGlueHiaSystem::Func8(class AActor* PtrWeapon, const struct FBulletHitInfoUploadData& UploadData, const struct FLocalShootHitData& LocalHitData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func8");

	UClientGlueHiaSystem_Func8_Params params;
	params.PtrWeapon = PtrWeapon;
	params.UploadData = UploadData;
	params.LocalHitData = LocalHitData;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func7
// (Final, Native, Private)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UClientGlueHiaSystem::Func7()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func7");

	UClientGlueHiaSystem_Func7_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func6
// (Final, Native, Private)
// Parameters:
// class AActor*                  Param1                         (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UClientGlueHiaSystem::Func6(class AActor* Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func6");

	UClientGlueHiaSystem_Func6_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func3
// (Final, Native, Private)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UClientGlueHiaSystem::Func3()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func3");

	UClientGlueHiaSystem_Func3_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func26
// (Final, Native, Private)
// Parameters:
// class AActor*                  Param4                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  Param5                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::Func26(class AActor* Param4, class AActor* Param5)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func26");

	UClientGlueHiaSystem_Func26_Params params;
	params.Param4 = Param4;
	params.Param5 = Param5;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func25
// (Final, Native, Private)
// Parameters:
// int                            Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          Param2                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          param3                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  Param4                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  Param5                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::Func25(int Param1, float Param2, float param3, class AActor* Param4, class AActor* Param5)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func25");

	UClientGlueHiaSystem_Func25_Params params;
	params.Param1 = Param1;
	params.Param2 = Param2;
	params.param3 = param3;
	params.Param4 = Param4;
	params.Param5 = Param5;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func24
// (Final, Native, Private)
// Parameters:
// int                            Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          Param2                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          param3                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          Param4                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  Param5                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  Param6                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::Func24(int Param1, float Param2, float param3, float Param4, class AActor* Param5, class AActor* Param6)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func24");

	UClientGlueHiaSystem_Func24_Params params;
	params.Param1 = Param1;
	params.Param2 = Param2;
	params.param3 = param3;
	params.Param4 = Param4;
	params.Param5 = Param5;
	params.Param6 = Param6;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func23
// (Final, Native, Private, HasOutParms, HasDefaults)
// Parameters:
// uint32_t                       Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 Param2                         (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FHitResult              param3                         (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void UClientGlueHiaSystem::Func23(uint32_t Param1, const struct FVector& Param2, const struct FHitResult& param3)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func23");

	UClientGlueHiaSystem_Func23_Params params;
	params.Param1 = Param1;
	params.Param2 = Param2;
	params.param3 = param3;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func22
// (Final, Native, Private, HasOutParms, HasDefaults)
// Parameters:
// uint32_t                       Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 Param2                         (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FVector                 param3                         (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void UClientGlueHiaSystem::Func22(uint32_t Param1, const struct FVector& Param2, const struct FVector& param3)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func22");

	UClientGlueHiaSystem_Func22_Params params;
	params.Param1 = Param1;
	params.Param2 = Param2;
	params.param3 = param3;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func21
// (Final, Native, Private)
// Parameters:
// class AActor*                  Param1                         (Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::Func21(class AActor* Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func21");

	UClientGlueHiaSystem_Func21_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func20
// (Final, Native, Private, HasOutParms, HasDefaults)
// Parameters:
// class AActor*                  Param1                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 Param2                         (Parm, OutParm, IsPlainOldData)

void UClientGlueHiaSystem::Func20(class AActor* Param1, struct FVector* Param2)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func20");

	UClientGlueHiaSystem_Func20_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (Param2 != nullptr)
		*Param2 = params.Param2;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func2
// (Final, Native, Private)
// Parameters:
// class AActor*                  CharacterPtr                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bParam1                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UClientGlueHiaSystem::Func2(class AActor* CharacterPtr, bool bParam1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func2");

	UClientGlueHiaSystem_Func2_Params params;
	params.CharacterPtr = CharacterPtr;
	params.bParam1 = bParam1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func19
// (Final, Native, Private)
// Parameters:
// uint32_t                       Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          Param2                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          param3                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::Func19(uint32_t Param1, float Param2, float param3)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func19");

	UClientGlueHiaSystem_Func19_Params params;
	params.Param1 = Param1;
	params.Param2 = Param2;
	params.param3 = param3;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func18
// (Final, Native, Private, HasOutParms)
// Parameters:
// TArray<struct FBazi>           Bazi                           (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TArray<struct FChori>          Chori                          (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UClientGlueHiaSystem::Func18(TArray<struct FBazi> Bazi, TArray<struct FChori> Chori)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func18");

	UClientGlueHiaSystem_Func18_Params params;
	params.Bazi = Bazi;
	params.Chori = Chori;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func17
// (Final, Native, Private, HasOutParms)
// Parameters:
// struct FFatalDamageParameter   Param1                         (ConstParm, Parm, OutParm, ReferenceParm)

void UClientGlueHiaSystem::Func17(const struct FFatalDamageParameter& Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func17");

	UClientGlueHiaSystem_Func17_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func16
// (Final, Native, Private)

void UClientGlueHiaSystem::Func16()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func16");

	UClientGlueHiaSystem_Func16_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func15
// (Final, Native, Private)
// Parameters:
// class AActor*                  Param1                         (Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::Func15(class AActor* Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func15");

	UClientGlueHiaSystem_Func15_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func14
// (Final, Native, Private, HasOutParms)
// Parameters:
// struct FShootTimeData          InData                         (ConstParm, Parm, OutParm, ReferenceParm)
// class AActor*                  PtrWeapon                      (Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::Func14(const struct FShootTimeData& InData, class AActor* PtrWeapon)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func14");

	UClientGlueHiaSystem_Func14_Params params;
	params.InData = InData;
	params.PtrWeapon = PtrWeapon;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func11
// (Final, Native, Private)
// Parameters:
// class AActor*                  Param1                         (Parm, ZeroConstructor, IsPlainOldData)
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UClientGlueHiaSystem::Func11(class AActor* Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func11");

	UClientGlueHiaSystem_Func11_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func10
// (Final, Native, Private)
// Parameters:
// class AActor*                  Param1                         (Parm, ZeroConstructor, IsPlainOldData)

void UClientGlueHiaSystem::Func10(class AActor* Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func10");

	UClientGlueHiaSystem_Func10_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.ClientGlueHiaSystem.Func1
// (Final, Native, Private, Const)
// Parameters:
// class AActor*                  CharacterPtr                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          TimeInSeconds                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          MarginInSeconds                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UClientGlueHiaSystem::Func1(class AActor* CharacterPtr, float TimeInSeconds, float MarginInSeconds)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientGlueHiaSystem.Func1");

	UClientGlueHiaSystem_Func1_Params params;
	params.CharacterPtr = CharacterPtr;
	params.TimeInSeconds = TimeInSeconds;
	params.MarginInSeconds = MarginInSeconds;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.SetUInt8ValueByName
// (Final, Native, Public)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// unsigned char                  Value                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::SetUInt8ValueByName(int Name, unsigned char Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.SetUInt8ValueByName");

	UFuzzyObject_SetUInt8ValueByName_Params params;
	params.Name = Name;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.SetUInt64ValueByName
// (Final, Native, Public)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// uint64_t                       Value                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::SetUInt64ValueByName(int Name, uint64_t Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.SetUInt64ValueByName");

	UFuzzyObject_SetUInt64ValueByName_Params params;
	params.Name = Name;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.SetUInt32ValueByName
// (Final, Native, Public)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Value                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::SetUInt32ValueByName(int Name, uint32_t Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.SetUInt32ValueByName");

	UFuzzyObject_SetUInt32ValueByName_Params params;
	params.Name = Name;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.SetUInt16ValueByName
// (Final, Native, Public)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// uint16_t                       Value                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::SetUInt16ValueByName(int Name, uint16_t Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.SetUInt16ValueByName");

	UFuzzyObject_SetUInt16ValueByName_Params params;
	params.Name = Name;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.SetInt8ValueByName
// (Final, Native, Public)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int8_t                         Value                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::SetInt8ValueByName(int Name, int8_t Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.SetInt8ValueByName");

	UFuzzyObject_SetInt8ValueByName_Params params;
	params.Name = Name;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.SetInt64ValueByName
// (Final, Native, Public)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        Value                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::SetInt64ValueByName(int Name, int64_t Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.SetInt64ValueByName");

	UFuzzyObject_SetInt64ValueByName_Params params;
	params.Name = Name;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.SetInt32ValueByName
// (Final, Native, Public)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            Value                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::SetInt32ValueByName(int Name, int Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.SetInt32ValueByName");

	UFuzzyObject_SetInt32ValueByName_Params params;
	params.Name = Name;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.SetInt16ValueByName
// (Final, Native, Public)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int16_t                        Value                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::SetInt16ValueByName(int Name, int16_t Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.SetInt16ValueByName");

	UFuzzyObject_SetInt16ValueByName_Params params;
	params.Name = Name;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.SetFloatValueByName
// (Final, Native, Public)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          Value                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::SetFloatValueByName(int Name, float Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.SetFloatValueByName");

	UFuzzyObject_SetFloatValueByName_Params params;
	params.Name = Name;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.SetBoolValueByName
// (Final, Native, Public)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           Value                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::SetBoolValueByName(int Name, bool Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.SetBoolValueByName");

	UFuzzyObject_SetBoolValueByName_Params params;
	params.Name = Name;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.GetUInt8ValueByName
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// unsigned char                  OutValue                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::GetUInt8ValueByName(int Name, unsigned char* OutValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.GetUInt8ValueByName");

	UFuzzyObject_GetUInt8ValueByName_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutValue != nullptr)
		*OutValue = params.OutValue;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.GetUInt64ValueByName
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// uint64_t                       OutValue                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::GetUInt64ValueByName(int Name, uint64_t* OutValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.GetUInt64ValueByName");

	UFuzzyObject_GetUInt64ValueByName_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutValue != nullptr)
		*OutValue = params.OutValue;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.GetUInt32ValueByName
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       OutValue                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::GetUInt32ValueByName(int Name, uint32_t* OutValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.GetUInt32ValueByName");

	UFuzzyObject_GetUInt32ValueByName_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutValue != nullptr)
		*OutValue = params.OutValue;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.GetUInt16ValueByName
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// uint16_t                       OutValue                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::GetUInt16ValueByName(int Name, uint16_t* OutValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.GetUInt16ValueByName");

	UFuzzyObject_GetUInt16ValueByName_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutValue != nullptr)
		*OutValue = params.OutValue;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.GetInt8ValueByName
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int8_t                         OutValue                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::GetInt8ValueByName(int Name, int8_t* OutValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.GetInt8ValueByName");

	UFuzzyObject_GetInt8ValueByName_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutValue != nullptr)
		*OutValue = params.OutValue;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.GetInt64ValueByName
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        OutValue                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::GetInt64ValueByName(int Name, int64_t* OutValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.GetInt64ValueByName");

	UFuzzyObject_GetInt64ValueByName_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutValue != nullptr)
		*OutValue = params.OutValue;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.GetInt32ValueByName
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            OutValue                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::GetInt32ValueByName(int Name, int* OutValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.GetInt32ValueByName");

	UFuzzyObject_GetInt32ValueByName_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutValue != nullptr)
		*OutValue = params.OutValue;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.GetInt16ValueByName
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int16_t                        OutValue                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::GetInt16ValueByName(int Name, int16_t* OutValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.GetInt16ValueByName");

	UFuzzyObject_GetInt16ValueByName_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutValue != nullptr)
		*OutValue = params.OutValue;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.GetFloatValueByName
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          OutValue                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::GetFloatValueByName(int Name, float* OutValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.GetFloatValueByName");

	UFuzzyObject_GetFloatValueByName_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutValue != nullptr)
		*OutValue = params.OutValue;

	return params.ReturnValue;
}


// Function HiggsBoson.FuzzyObject.GetBoolValueByName
// (Final, Native, Public, HasOutParms, Const)
// Parameters:
// int                            Name                           (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           OutValue                       (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFuzzyObject::GetBoolValueByName(int Name, bool* OutValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.FuzzyObject.GetBoolValueByName");

	UFuzzyObject_GetBoolValueByName_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutValue != nullptr)
		*OutValue = params.OutValue;

	return params.ReturnValue;
}


// Function HiggsBoson.ClientAmaUbaSubsystem.Func1
// (Final, Native, Private)
// Parameters:
// int                            IntType                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          InTimestamp                    (Parm, ZeroConstructor, IsPlainOldData)
// int                            IncreaseCount                  (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bAlertUploadFrequency          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UClientAmaUbaSubsystem::Func1(int IntType, float InTimestamp, int IncreaseCount, bool bAlertUploadFrequency)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.ClientAmaUbaSubsystem.Func1");

	UClientAmaUbaSubsystem_Func1_Params params;
	params.IntType = IntType;
	params.InTimestamp = InTimestamp;
	params.IncreaseCount = IncreaseCount;
	params.bAlertUploadFrequency = bAlertUploadFrequency;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.CamoyoHelper.MakeRectTu
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FScriptDelegate         CamoyoRetDelegate              (Parm, ZeroConstructor)
// struct FString                 Filename                       (Parm, ZeroConstructor)
// int                            Quality                        (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bShowUI                        (Parm, ZeroConstructor, IsPlainOldData)

void UCamoyoHelper::MakeRectTu(const struct FScriptDelegate& CamoyoRetDelegate, const struct FString& Filename, int Quality, bool bShowUI)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.CamoyoHelper.MakeRectTu");

	UCamoyoHelper_MakeRectTu_Params params;
	params.CamoyoRetDelegate = CamoyoRetDelegate;
	params.Filename = Filename;
	params.Quality = Quality;
	params.bShowUI = bShowUI;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.CamoyoHelper.MakeMemPerform
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// int                            InbOpen                        (Parm, ZeroConstructor, IsPlainOldData)

void UCamoyoHelper::MakeMemPerform(int InbOpen)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.CamoyoHelper.MakeMemPerform");

	UCamoyoHelper_MakeMemPerform_Params params;
	params.InbOpen = InbOpen;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.CamoyoHelper.MakeFitRectTu
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FScriptDelegate         CamoyoRetDelegate              (Parm, ZeroConstructor)
// struct FVector4                InCutParam                     (Parm, IsPlainOldData)
// int                            InTuType                       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           isShowUI                       (Parm, ZeroConstructor, IsPlainOldData)

void UCamoyoHelper::MakeFitRectTu(const struct FScriptDelegate& CamoyoRetDelegate, const struct FVector4& InCutParam, int InTuType, bool isShowUI)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.CamoyoHelper.MakeFitRectTu");

	UCamoyoHelper_MakeFitRectTu_Params params;
	params.CamoyoRetDelegate = CamoyoRetDelegate;
	params.InCutParam = InCutParam;
	params.InTuType = InTuType;
	params.isShowUI = isShowUI;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.Zanwu
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)
// Parameters:
// struct FString                 Param1                         (Parm, ZeroConstructor)

void UHiggsBosonComponent::Zanwu(const struct FString& Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.Zanwu");

	UHiggsBosonComponent_Zanwu_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.SyncServerParam
// (Final, Native, Public)
// Parameters:
// bool                           Param1                         (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::SyncServerParam(bool Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.SyncServerParam");

	UHiggsBosonComponent_SyncServerParam_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.SwiftHawk
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)
// Parameters:
// TArray<unsigned char>          Hawks                          (ConstParm, Parm, ZeroConstructor, ReferenceParm)
// uint32_t                       Magic                          (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::SwiftHawk(TArray<unsigned char> Hawks, uint32_t Magic)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.SwiftHawk");

	UHiggsBosonComponent_SwiftHawk_Params params;
	params.Hawks = Hawks;
	params.Magic = Magic;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ShowABCD
// (Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 Message                        (Parm, ZeroConstructor)
// bool                           bIsClientShowWindow            (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::ShowABCD(const struct FString& Message, bool bIsClientShowWindow)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ShowABCD");

	UHiggsBosonComponent_ShowABCD_Params params;
	params.Message = Message;
	params.bIsClientShowWindow = bIsClientShowWindow;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.SetSchemeForInitialize
// (Final, Native, Public)
// Parameters:
// int                            Index                          (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       VerifyLen                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          VerifyHashArray                (Parm, ZeroConstructor)
// TArray<struct FPatchPoint>     PatchPointArray                (Parm, ZeroConstructor)

void UHiggsBosonComponent::SetSchemeForInitialize(int Index, uint32_t VerifyLen, TArray<unsigned char> VerifyHashArray, TArray<struct FPatchPoint> PatchPointArray)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.SetSchemeForInitialize");

	UHiggsBosonComponent_SetSchemeForInitialize_Params params;
	params.Index = Index;
	params.VerifyLen = VerifyLen;
	params.VerifyHashArray = VerifyHashArray;
	params.PatchPointArray = PatchPointArray;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.SetSchemeForGet
// (Final, Native, Public)
// Parameters:
// int                            Index                          (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       VerifyLen                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          VerifyHashArray                (Parm, ZeroConstructor)
// TArray<struct FPatchPoint>     PatchPointArray                (Parm, ZeroConstructor)

void UHiggsBosonComponent::SetSchemeForGet(int Index, uint32_t VerifyLen, TArray<unsigned char> VerifyHashArray, TArray<struct FPatchPoint> PatchPointArray)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.SetSchemeForGet");

	UHiggsBosonComponent_SetSchemeForGet_Params params;
	params.Index = Index;
	params.VerifyLen = VerifyLen;
	params.VerifyHashArray = VerifyHashArray;
	params.PatchPointArray = PatchPointArray;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ServerPoPo
// (Final, Native, Private, HasOutParms)
// Parameters:
// TArray<unsigned char>          Array                          (Parm, OutParm, ZeroConstructor)

void UHiggsBosonComponent::ServerPoPo(TArray<unsigned char>* Array)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ServerPoPo");

	UHiggsBosonComponent_ServerPoPo_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (Array != nullptr)
		*Array = params.Array;
}


// Function HiggsBoson.HiggsBosonComponent.SendMoveStatusToServer
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)
// Parameters:
// EPawnState                     State                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::SendMoveStatusToServer(EPawnState State)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.SendMoveStatusToServer");

	UHiggsBosonComponent_SendMoveStatusToServer_Params params;
	params.State = State;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.S2CNuoro
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)
// Parameters:
// int                            Lotion                         (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::S2CNuoro(int Lotion)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.S2CNuoro");

	UHiggsBosonComponent_S2CNuoro_Params params;
	params.Lotion = Lotion;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.RPC_ServerGlueHiaPark
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)
// Parameters:
// int8_t                         HiaType                        (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          GlueHiaParkArr                 (ConstParm, Parm, ZeroConstructor, ReferenceParm)
// uint32_t                       HiaStatus                      (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          GlueArg                        (ConstParm, Parm, ZeroConstructor, ReferenceParm)
// TArray<unsigned char>          GlueHiaParkArr2                (ConstParm, Parm, ZeroConstructor, ReferenceParm)
// uint32_t                       HiaStatus2                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::RPC_ServerGlueHiaPark(int8_t HiaType, TArray<unsigned char> GlueHiaParkArr, uint32_t HiaStatus, TArray<unsigned char> GlueArg, TArray<unsigned char> GlueHiaParkArr2, uint32_t HiaStatus2)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.RPC_ServerGlueHiaPark");

	UHiggsBosonComponent_RPC_ServerGlueHiaPark_Params params;
	params.HiaType = HiaType;
	params.GlueHiaParkArr = GlueHiaParkArr;
	params.HiaStatus = HiaStatus;
	params.GlueArg = GlueArg;
	params.GlueHiaParkArr2 = GlueHiaParkArr2;
	params.HiaStatus2 = HiaStatus2;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.RPC_ServerCapbo
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)
// Parameters:
// int8_t                         BoCapC                         (Parm, ZeroConstructor, IsPlainOldData)
// int8_t                         InBoType                       (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          BoDataArr                      (ConstParm, Parm, ZeroConstructor, ReferenceParm)

void UHiggsBosonComponent::RPC_ServerCapbo(int8_t BoCapC, int8_t InBoType, TArray<unsigned char> BoDataArr)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.RPC_ServerCapbo");

	UHiggsBosonComponent_RPC_ServerCapbo_Params params;
	params.BoCapC = BoCapC;
	params.InBoType = InBoType;
	params.BoDataArr = BoDataArr;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.RPC_ServerAddInvalidFilesInPakLite
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)
// Parameters:
// TArray<int>                    InvalidIndexList               (ConstParm, Parm, ZeroConstructor, ReferenceParm)

void UHiggsBosonComponent::RPC_ServerAddInvalidFilesInPakLite(TArray<int> InvalidIndexList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.RPC_ServerAddInvalidFilesInPakLite");

	UHiggsBosonComponent_RPC_ServerAddInvalidFilesInPakLite_Params params;
	params.InvalidIndexList = InvalidIndexList;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.RPC_ClientCoronaLab
// (Net, NetReliable, Native, Event, Public, NetClient, NetValidate)
// Parameters:
// unsigned char                  bAllSwitch                     (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          CoronaLab                      (ConstParm, Parm, ZeroConstructor, ReferenceParm)
// uint32_t                       CoronaState                    (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::RPC_ClientCoronaLab(unsigned char bAllSwitch, TArray<unsigned char> CoronaLab, uint32_t CoronaState)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.RPC_ClientCoronaLab");

	UHiggsBosonComponent_RPC_ClientCoronaLab_Params params;
	params.bAllSwitch = bAllSwitch;
	params.CoronaLab = CoronaLab;
	params.CoronaState = CoronaState;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnWeaponAimInput
// (Final, Native, Public)
// Parameters:
// float                          InDistToEnemy                  (Parm, ZeroConstructor, IsPlainOldData)
// float                          InYaw                          (Parm, ZeroConstructor, IsPlainOldData)
// float                          InPitch                        (Parm, ZeroConstructor, IsPlainOldData)
// float                          InRoll                         (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnWeaponAimInput(float InDistToEnemy, float InYaw, float InPitch, float InRoll)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnWeaponAimInput");

	UHiggsBosonComponent_OnWeaponAimInput_Params params;
	params.InDistToEnemy = InDistToEnemy;
	params.InYaw = InYaw;
	params.InPitch = InPitch;
	params.InRoll = InRoll;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnTouchInput
// (Final, Native, Public)
// Parameters:
// float                          InYaw                          (Parm, ZeroConstructor, IsPlainOldData)
// float                          InPitch                        (Parm, ZeroConstructor, IsPlainOldData)
// float                          InRoll                         (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnTouchInput(float InYaw, float InPitch, float InRoll)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnTouchInput");

	UHiggsBosonComponent_OnTouchInput_Params params;
	params.InYaw = InYaw;
	params.InPitch = InPitch;
	params.InRoll = InRoll;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnStopFireEvent
// (Final, Native, Public)

void UHiggsBosonComponent::OnStopFireEvent()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnStopFireEvent");

	UHiggsBosonComponent_OnStopFireEvent_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnStartFireEvent
// (Final, Native, Public)

void UHiggsBosonComponent::OnStartFireEvent()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnStartFireEvent");

	UHiggsBosonComponent_OnStartFireEvent_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnSkillInteruptVisual
// (Final, Native, Public)
// Parameters:
// class AActor*                  InTarget                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  InCauser                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnSkillInteruptVisual(class AActor* InTarget, class AActor* InCauser)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnSkillInteruptVisual");

	UHiggsBosonComponent_OnSkillInteruptVisual_Params params;
	params.InTarget = InTarget;
	params.InCauser = InCauser;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnSkillEndVisual
// (Final, Native, Public)
// Parameters:
// class AActor*                  InTarget                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  InCauser                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnSkillEndVisual(class AActor* InTarget, class AActor* InCauser)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnSkillEndVisual");

	UHiggsBosonComponent_OnSkillEndVisual_Params params;
	params.InTarget = InTarget;
	params.InCauser = InCauser;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnSkillEndTrans
// (Final, Native, Public)
// Parameters:
// class AActor*                  InTarget                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  InCauser                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnSkillEndTrans(class AActor* InTarget, class AActor* InCauser)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnSkillEndTrans");

	UHiggsBosonComponent_OnSkillEndTrans_Params params;
	params.InTarget = InTarget;
	params.InCauser = InCauser;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnSkillBeginVisual
// (Final, Native, Public)
// Parameters:
// class AActor*                  InTarget                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  InCauser                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnSkillBeginVisual(class AActor* InTarget, class AActor* InCauser)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnSkillBeginVisual");

	UHiggsBosonComponent_OnSkillBeginVisual_Params params;
	params.InTarget = InTarget;
	params.InCauser = InCauser;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnSkillBeginTrans
// (Final, Native, Public)
// Parameters:
// class AActor*                  InTarget                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class AActor*                  InCauser                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnSkillBeginTrans(class AActor* InTarget, class AActor* InCauser)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnSkillBeginTrans");

	UHiggsBosonComponent_OnSkillBeginTrans_Params params;
	params.InTarget = InTarget;
	params.InCauser = InCauser;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnRecoilCurveCheckFailed
// (Final, Native, Public)
// Parameters:
// class AActor*                  Weapon                         (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnRecoilCurveCheckFailed(class AActor* Weapon)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnRecoilCurveCheckFailed");

	UHiggsBosonComponent_OnRecoilCurveCheckFailed_Params params;
	params.Weapon = Weapon;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeOut
// (Final, Native, Public)
// Parameters:
// bool                           bBegan                         (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnPlayerScopeOut(bool bBegan)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeOut");

	UHiggsBosonComponent_OnPlayerScopeOut_Params params;
	params.bBegan = bBegan;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeIn
// (Final, Native, Public)
// Parameters:
// bool                           bBegan                         (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnPlayerScopeIn(bool bBegan)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeIn");

	UHiggsBosonComponent_OnPlayerScopeIn_Params params;
	params.bBegan = bBegan;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnMyPawnRespawn
// (Final, Native, Public)
// Parameters:
// class AUAEPlayerController*    InPlayerController             (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnMyPawnRespawn(class AUAEPlayerController* InPlayerController)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnMyPawnRespawn");

	UHiggsBosonComponent_OnMyPawnRespawn_Params params;
	params.InPlayerController = InPlayerController;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnKillSomeOneEvent
// (Final, Native, Public)
// Parameters:
// class AActor*                  InSomeOne                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnKillSomeOneEvent(class AActor* InSomeOne)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnKillSomeOneEvent");

	UHiggsBosonComponent_OnKillSomeOneEvent_Params params;
	params.InSomeOne = InSomeOne;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnGyroInput
// (Final, Native, Public)
// Parameters:
// float                          InYaw                          (Parm, ZeroConstructor, IsPlainOldData)
// float                          InPitch                        (Parm, ZeroConstructor, IsPlainOldData)
// float                          InRoll                         (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnGyroInput(float InYaw, float InPitch, float InRoll)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnGyroInput");

	UHiggsBosonComponent_OnGyroInput_Params params;
	params.InYaw = InYaw;
	params.InPitch = InPitch;
	params.InRoll = InRoll;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnClientAdjustPosition
// (Final, Native, Public, HasDefaults)
// Parameters:
// struct FVector                 NewLoc                         (Parm, IsPlainOldData)
// ECharacterMoveDragReason       Reason                         (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::OnClientAdjustPosition(const struct FVector& NewLoc, ECharacterMoveDragReason Reason)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnClientAdjustPosition");

	UHiggsBosonComponent_OnClientAdjustPosition_Params params;
	params.NewLoc = NewLoc;
	params.Reason = Reason;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnCapboReturn
// (Final, Native, Public, HasOutParms)
// Parameters:
// int                            BoCapC                         (Parm, ZeroConstructor, IsPlainOldData)
// int                            InBoType                       (Parm, ZeroConstructor, IsPlainOldData)
// TArray<unsigned char>          RetData                        (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UHiggsBosonComponent::OnCapboReturn(int BoCapC, int InBoType, TArray<unsigned char> RetData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnCapboReturn");

	UHiggsBosonComponent_OnCapboReturn_Params params;
	params.BoCapC = BoCapC;
	params.InBoType = InBoType;
	params.RetData = RetData;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.OnBulletImpactEvent
// (Final, Native, Public, HasOutParms)
// Parameters:
// class AActor*                  InCauser                       (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FHitResult              InImpactResult                 (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void UHiggsBosonComponent::OnBulletImpactEvent(class AActor* InCauser, const struct FHitResult& InImpactResult)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.OnBulletImpactEvent");

	UHiggsBosonComponent_OnBulletImpactEvent_Params params;
	params.InCauser = InCauser;
	params.InImpactResult = InImpactResult;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.IsCharacterOwnerWerewolf
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UHiggsBosonComponent::IsCharacterOwnerWerewolf()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.IsCharacterOwnerWerewolf");

	UHiggsBosonComponent_IsCharacterOwnerWerewolf_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.HiggsBosonComponent.HandleClientReconnect
// (Final, Native, Public)

void UHiggsBosonComponent::HandleClientReconnect()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.HandleClientReconnect");

	UHiggsBosonComponent_HandleClientReconnect_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.FlushGameEnd
// (Final, Native, Public)

void UHiggsBosonComponent::FlushGameEnd()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.FlushGameEnd");

	UHiggsBosonComponent_FlushGameEnd_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.Ezio
// (Final, Net, NetReliable, Native, Event, Private, NetServer, NetValidate)
// Parameters:
// int                            Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            Param2                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            param3                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            Param4                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::Ezio(int Param1, int Param2, int param3, int Param4)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.Ezio");

	UHiggsBosonComponent_Ezio_Params params;
	params.Param1 = Param1;
	params.Param2 = Param2;
	params.param3 = param3;
	params.Param4 = Param4;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.EnableTickEncrypt
// (Final, Native, Public)
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UHiggsBosonComponent::EnableTickEncrypt()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.EnableTickEncrypt");

	UHiggsBosonComponent_EnableTickEncrypt_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.HiggsBosonComponent.EnablePeekShootVerify
// (Final, Native, Public)
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UHiggsBosonComponent::EnablePeekShootVerify()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.EnablePeekShootVerify");

	UHiggsBosonComponent_EnablePeekShootVerify_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.HiggsBosonComponent.EnableEnhancedDynamicActors
// (Final, Native, Public)
// Parameters:
// int                            Index                          (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::EnableEnhancedDynamicActors(int Index)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.EnableEnhancedDynamicActors");

	UHiggsBosonComponent_EnableEnhancedDynamicActors_Params params;
	params.Index = Index;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.EnableCheckFilesInPakLite
// (Final, Native, Public)
// Parameters:
// TArray<struct FString>         InFiles                        (ConstParm, Parm, ZeroConstructor)
// int                            InVerifyCountSinglePass        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UHiggsBosonComponent::EnableCheckFilesInPakLite(TArray<struct FString> InFiles, int InVerifyCountSinglePass)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.EnableCheckFilesInPakLite");

	UHiggsBosonComponent_EnableCheckFilesInPakLite_Params params;
	params.InFiles = InFiles;
	params.InVerifyCountSinglePass = InVerifyCountSinglePass;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function HiggsBoson.HiggsBosonComponent.DispatchIntegrityCheckItem
// (Final, Native, Public)
// Parameters:
// uint32_t                       PlatID                         (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       AreaID                         (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       GameBits                       (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Index                          (Parm, ZeroConstructor, IsPlainOldData)
// int                            Offset                         (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Len                            (Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       Type                           (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::DispatchIntegrityCheckItem(uint32_t PlatID, uint32_t AreaID, uint32_t GameBits, uint32_t Index, int Offset, uint32_t Len, uint32_t Type)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.DispatchIntegrityCheckItem");

	UHiggsBosonComponent_DispatchIntegrityCheckItem_Params params;
	params.PlatID = PlatID;
	params.AreaID = AreaID;
	params.GameBits = GameBits;
	params.Index = Index;
	params.Offset = Offset;
	params.Len = Len;
	params.Type = Type;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.DevPVSCheckClientLocationC2S
// (Net, NetReliable, Native, Event, Public, NetServer, HasDefaults, NetValidate)
// Parameters:
// class ASTExtraBaseCharacter*   PtrOtherCharacter              (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 D                              (ConstParm, Parm, ReferenceParm, IsPlainOldData)
// struct FVector                 A                              (ConstParm, Parm, ReferenceParm, IsPlainOldData)
// struct FVector                 V                              (ConstParm, Parm, ReferenceParm, IsPlainOldData)
// struct FVector                 C                              (ConstParm, Parm, ReferenceParm, IsPlainOldData)
// bool                           b1                             (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::DevPVSCheckClientLocationC2S(class ASTExtraBaseCharacter* PtrOtherCharacter, const struct FVector& D, const struct FVector& A, const struct FVector& V, const struct FVector& C, bool b1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.DevPVSCheckClientLocationC2S");

	UHiggsBosonComponent_DevPVSCheckClientLocationC2S_Params params;
	params.PtrOtherCharacter = PtrOtherCharacter;
	params.D = D;
	params.A = A;
	params.V = V;
	params.C = C;
	params.b1 = b1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.DevPVSCheckClientLocation
// (Net, NetReliable, Native, Event, Public, HasDefaults, NetClient, NetValidate)
// Parameters:
// class AActor*                  PtrSimulatedProxy              (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 D                              (ConstParm, Parm, ReferenceParm, IsPlainOldData)

void UHiggsBosonComponent::DevPVSCheckClientLocation(class AActor* PtrSimulatedProxy, const struct FVector& D)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.DevPVSCheckClientLocation");

	UHiggsBosonComponent_DevPVSCheckClientLocation_Params params;
	params.PtrSimulatedProxy = PtrSimulatedProxy;
	params.D = D;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.DevPrintMouke
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)
// Parameters:
// struct FString                 Param0                         (Parm, ZeroConstructor)
// float                          Param1                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 param3                         (Parm, ZeroConstructor)

void UHiggsBosonComponent::DevPrintMouke(const struct FString& Param0, float Param1, const struct FString& param3)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.DevPrintMouke");

	UHiggsBosonComponent_DevPrintMouke_Params params;
	params.Param0 = Param0;
	params.Param1 = Param1;
	params.param3 = param3;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ControlRoofTouch
// (Final, Native, Public)
// Parameters:
// int                            Switch                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::ControlRoofTouch(int Switch)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ControlRoofTouch");

	UHiggsBosonComponent_ControlRoofTouch_Params params;
	params.Switch = Switch;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ControlMoveInputRecord
// (Final, Native, Public)
// Parameters:
// int                            Switch                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          RecordCooldown                 (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            BitmapSize                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// int                            MinValidSampleCount            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       InAngleSampleMaxCount          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// uint32_t                       InAngleDistributionNum         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::ControlMoveInputRecord(int Switch, float RecordCooldown, int BitmapSize, int MinValidSampleCount, uint32_t InAngleSampleMaxCount, uint32_t InAngleDistributionNum)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ControlMoveInputRecord");

	UHiggsBosonComponent_ControlMoveInputRecord_Params params;
	params.Switch = Switch;
	params.RecordCooldown = RecordCooldown;
	params.BitmapSize = BitmapSize;
	params.MinValidSampleCount = MinValidSampleCount;
	params.InAngleSampleMaxCount = InAngleSampleMaxCount;
	params.InAngleDistributionNum = InAngleDistributionNum;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ControlMHActive
// (Final, Native, Public)
// Parameters:
// int                            Switch                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::ControlMHActive(int Switch)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ControlMHActive");

	UHiggsBosonComponent_ControlMHActive_Params params;
	params.Switch = Switch;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.Cofew
// (Final, Native, Public)
// Parameters:
// uint32_t                       InIter                         (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::Cofew(uint32_t InIter)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.Cofew");

	UHiggsBosonComponent_Cofew_Params params;
	params.InIter = InIter;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawkWithParams
// (Net, NetReliable, Native, Event, Public, NetClient)
// Parameters:
// TArray<unsigned char>          Hawks                          (ConstParm, Parm, ZeroConstructor, ReferenceParm)

void UHiggsBosonComponent::ClientSwiftHawkWithParams(TArray<unsigned char> Hawks)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawkWithParams");

	UHiggsBosonComponent_ClientSwiftHawkWithParams_Params params;
	params.Hawks = Hawks;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawk
// (Net, NetReliable, Native, Event, Public, NetClient)
// Parameters:
// unsigned char                  Type                           (Parm, ZeroConstructor, IsPlainOldData)
// int                            SequenceID                     (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::ClientSwiftHawk(unsigned char Type, int SequenceID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawk");

	UHiggsBosonComponent_ClientSwiftHawk_Params params;
	params.Type = Type;
	params.SequenceID = SequenceID;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ClientReceiveEx
// (Final, Net, Native, Event, Private, NetClient, NetValidate)
// Parameters:
// TArray<unsigned char>          RPCConstArray                  (ConstParm, Parm, ZeroConstructor, ReferenceParm)

void UHiggsBosonComponent::ClientReceiveEx(TArray<unsigned char> RPCConstArray)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ClientReceiveEx");

	UHiggsBosonComponent_ClientReceiveEx_Params params;
	params.RPCConstArray = RPCConstArray;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ClientDoJT
// (Final, Native, Public)
// Parameters:
// bool                           bDelayUntilShot                (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::ClientDoJT(bool bDelayUntilShot)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ClientDoJT");

	UHiggsBosonComponent_ClientDoJT_Params params;
	params.bDelayUntilShot = bDelayUntilShot;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ClientCloseBaziUI
// (Net, NetReliable, Native, Event, Public, NetClient)
// Parameters:
// TArray<struct FBazi>           Bazi                           (ConstParm, Parm, ZeroConstructor, ReferenceParm)
// TArray<struct FChori>          Chori                          (ConstParm, Parm, ZeroConstructor, ReferenceParm)

void UHiggsBosonComponent::ClientCloseBaziUI(TArray<struct FBazi> Bazi, TArray<struct FChori> Chori)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ClientCloseBaziUI");

	UHiggsBosonComponent_ClientCloseBaziUI_Params params;
	params.Bazi = Bazi;
	params.Chori = Chori;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.ClientAccom
// (Net, NetReliable, Native, Event, Public, NetClient)
// Parameters:
// uint16_t                       Owea                           (Parm, ZeroConstructor, IsPlainOldData)

void UHiggsBosonComponent::ClientAccom(uint16_t Owea)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.ClientAccom");

	UHiggsBosonComponent_ClientAccom_Params params;
	params.Owea = Owea;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.HiggsBosonComponent.C2SSendAlert
// (Final, Net, NetReliable, Native, Event, Private, NetServer, NetValidate)
// Parameters:
// struct FString                 Param1                         (Parm, ZeroConstructor)

void UHiggsBosonComponent::C2SSendAlert(const struct FString& Param1)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.HiggsBosonComponent.C2SSendAlert");

	UHiggsBosonComponent_C2SSendAlert_Params params;
	params.Param1 = Param1;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.MarginIntervalCharacterTicker.Reset
// (Final, Native, Private)

void UMarginIntervalCharacterTicker::Reset()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.MarginIntervalCharacterTicker.Reset");

	UMarginIntervalCharacterTicker_Reset_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.SecurityAvatarSystem.OnAvatarRectifyDataChange
// (Final, Native, Public)
// Parameters:
// class AUAECharacter*           CharacterOwner                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            ItemId                         (Parm, ZeroConstructor, IsPlainOldData)

void USecurityAvatarSystem::OnAvatarRectifyDataChange(class AUAECharacter* CharacterOwner, int ItemId)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.SecurityAvatarSystem.OnAvatarRectifyDataChange");

	USecurityAvatarSystem_OnAvatarRectifyDataChange_Params params;
	params.CharacterOwner = CharacterOwner;
	params.ItemId = ItemId;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.SecurityAvatarSystem.OnAvatarEquipped
// (Final, Native, Public, HasOutParms)
// Parameters:
// class AUAECharacter*           CharacterOwner                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            SlotID                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FItemDefineID           NewItemID                      (ConstParm, Parm, OutParm, ReferenceParm)
// struct FItemDefineID           OldItemID                      (ConstParm, Parm, OutParm, ReferenceParm)

void USecurityAvatarSystem::OnAvatarEquipped(class AUAECharacter* CharacterOwner, int SlotID, const struct FItemDefineID& NewItemID, const struct FItemDefineID& OldItemID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.SecurityAvatarSystem.OnAvatarEquipped");

	USecurityAvatarSystem_OnAvatarEquipped_Params params;
	params.CharacterOwner = CharacterOwner;
	params.SlotID = SlotID;
	params.NewItemID = NewItemID;
	params.OldItemID = OldItemID;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.SecurityImprisonComp.ReleaseTeammate
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)
// Parameters:
// uint64_t                       PlayerUID                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void USecurityImprisonComp::ReleaseTeammate(uint64_t PlayerUID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.SecurityImprisonComp.ReleaseTeammate");

	USecurityImprisonComp_ReleaseTeammate_Params params;
	params.PlayerUID = PlayerUID;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.SecurityImprisonComp.ImprisonmentUIUpdate
// (Net, NetReliable, Native, Event, Public, NetClient, NetValidate)
// Parameters:
// uint64_t                       PlayerUID                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIsImprison                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void USecurityImprisonComp::ImprisonmentUIUpdate(uint64_t PlayerUID, bool bIsImprison)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.SecurityImprisonComp.ImprisonmentUIUpdate");

	USecurityImprisonComp_ImprisonmentUIUpdate_Params params;
	params.PlayerUID = PlayerUID;
	params.bIsImprison = bIsImprison;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.SecurityImprisonComp.ImprisonmentTeammate
// (Net, NetReliable, Native, Event, Public, NetServer, NetValidate)
// Parameters:
// uint64_t                       PlayerUID                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bIscomplaint                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void USecurityImprisonComp::ImprisonmentTeammate(uint64_t PlayerUID, bool bIscomplaint)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.SecurityImprisonComp.ImprisonmentTeammate");

	USecurityImprisonComp_ImprisonmentTeammate_Params params;
	params.PlayerUID = PlayerUID;
	params.bIscomplaint = bIscomplaint;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.SecurityImprisonComp.ImprisonmentReport
// (Final, Native, Public)
// Parameters:
// uint64_t                       PlayerUID                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void USecurityImprisonComp::ImprisonmentReport(uint64_t PlayerUID)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.SecurityImprisonComp.ImprisonmentReport");

	USecurityImprisonComp_ImprisonmentReport_Params params;
	params.PlayerUID = PlayerUID;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.TimeIntervalPawnStateHistorySystem.UpdateParams
// (Final, Native, Private)

void UTimeIntervalPawnStateHistorySystem::UpdateParams()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.TimeIntervalPawnStateHistorySystem.UpdateParams");

	UTimeIntervalPawnStateHistorySystem_UpdateParams_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function HiggsBoson.TimeIntervalPawnStateHistorySystem.QueryHistoryMaxVelocity
// (Final, Native, Private, HasOutParms)
// Parameters:
// uint64_t                       UID                            (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          CenterTime                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          MarginTime                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          OutMaxZVelocity                (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// float                          OutMaxXYVelocity               (Parm, OutParm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UTimeIntervalPawnStateHistorySystem::QueryHistoryMaxVelocity(uint64_t UID, float CenterTime, float MarginTime, float* OutMaxZVelocity, float* OutMaxXYVelocity)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function HiggsBoson.TimeIntervalPawnStateHistorySystem.QueryHistoryMaxVelocity");

	UTimeIntervalPawnStateHistorySystem_QueryHistoryMaxVelocity_Params params;
	params.UID = UID;
	params.CenterTime = CenterTime;
	params.MarginTime = MarginTime;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutMaxZVelocity != nullptr)
		*OutMaxZVelocity = params.OutMaxZVelocity;
	if (OutMaxXYVelocity != nullptr)
		*OutMaxXYVelocity = params.OutMaxXYVelocity;

	return params.ReturnValue;
}


}

