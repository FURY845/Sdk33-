#pragma once

// PUBG MOBILE (3.8.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Wed May  7 14:35:35 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function LuaHotReload.LuaHotReloadHelper.OnLuaFileHotUpdate
struct ULuaHotReloadHelper_OnLuaFileHotUpdate_Params
{
	struct FString                                     NotifyMessage;                                            // (Parm, ZeroConstructor)
};

}

